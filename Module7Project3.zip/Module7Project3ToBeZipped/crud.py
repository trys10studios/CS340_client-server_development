#Python Code to Insert a Document
from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, USER, PASS):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = 'hotdogFlavoredWater!'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30556
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        try:
            # Initialize MongoDB connection
            self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
            self.database = self.client['%s' % (DB)]
            self.collection = self.database['%s' % (COL)]
        except errors.ConnectionError as e:
            print(f"Error connecting to MongoDB: {e}")

    def check_connection(self):
        try:
            # Attempt to get a list of collections in the database
            self.client.admin.command('ping')  # This pings the database to check connection
            print("Connection is active.")
            return True
        except errors.ConnectionError as e:
            print(f"Error connecting to MongoDB: {e}")
            return False
                
# Create method to implement the C in CRUD.
    def create(self, data):
        try:
            if data is None:
                raise ValueError("Nothing to save, because data parameter is empty")

            result = self.database.animals.insert_one(data)  # data should be a dictionary
            return result.acknowledged  # Return True if the insert is successful

        except Exception as e:
            print(f"Error in create operation: {e}")

# Read method to implement the R in CRUD.
    def read(self, query):
        try:
            if query is not None:
                cursor = self.collection.find(query)  
                return list(cursor)  # Return the results as a list
            else:
                raise ValueError("Nothing to read, because query parameter is empty")
        except Exception as e:
            print(f"Error in read operation: {e}")
            
# Update method to implement the U in CRUD.
    def update(self, query, update_data, update_many=False):
        try:
            if not query or not isinstance(query, dict):
                raise ValueError("The query must be a non-empty dictionary.")
            if not update_data or not isinstance(update_data, dict):
                raise ValueError("The update_data must be a non-empty dictionary.")

            if update_many:
                result = self.collection.update_many(query, {'$set': update_data})
            else:
                result = self.collection.update_one(query, {'$set': update_data})

            return result.modified_count  # Return the number of modified documents
        except Exception as e:
            print(f"Error in update operation: {e}")
            return 0

# Delete method to implement the D in CRUD.
    def delete(self, query, delete_many=False):
        try:
            if not query or not isinstance(query, dict):
                raise ValueError("The query must be a non-empty dictionary.")

            if delete_many:
                result = self.collection.delete_many(query)
            else:
                result = self.collection.delete_one(query)

            return result.deleted_count  # Return the number of deleted documents
        except Exception as e:
            print(f"Error in delete operation: {e}")
            return 0